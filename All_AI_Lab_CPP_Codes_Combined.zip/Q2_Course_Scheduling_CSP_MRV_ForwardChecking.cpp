#include <iostream>
#include <vector>
#include <string>
using namespace std;

vector<string> courses = {"AI", "DBMS", "OS", "CN"};

vector<vector<int>> domains = {
    {1, 2, 3},    // AI
    {1, 2, 4},    // DBMS
    {2, 3, 4},    // OS
    {1, 3, 4}     // CN
};

bool conflict(int a, int b) {
    // AI and DBMS
    if ((a == 0 && b == 1) || (a == 1 && b == 0))
        return true;

    // AI and OS
    if ((a == 0 && b == 2) || (a == 2 && b == 0))
        return true;

    // DBMS and CN
    if ((a == 1 && b == 3) || (a == 3 && b == 1))
        return true;

    // OS and CN
    if ((a == 2 && b == 3) || (a == 3 && b == 2))
        return true;

    return false;
}

bool safe(int course, int slot, vector<int>& assignment) {
    for (int i = 0; i < 4; i++) {
        if (assignment[i] != -1 &&
            conflict(course, i) &&
            assignment[i] == slot) {
            return false;
        }
    }

    return true;
}

bool simpleBacktracking(int course, vector<int>& assignment) {
    if (course == 4)
        return true;

    for (int slot : domains[course]) {
        cout << "Try " << courses[course]
             << " = Slot " << slot << "\n";

        if (safe(course, slot, assignment)) {
            assignment[course] = slot;

            if (simpleBacktracking(course + 1, assignment))
                return true;

            cout << "Backtrack from " << courses[course] << "\n";
            assignment[course] = -1;
        }
    }

    return false;
}

int countAvailable(int course,
                   vector<int>& assignment,
                   vector<vector<int>>& currentDomains) {
    int count = 0;

    for (int slot : currentDomains[course]) {
        if (safe(course, slot, assignment))
            count++;
    }

    return count;
}

int chooseMRV(vector<int>& assignment,
              vector<vector<int>>& currentDomains) {
    int best = -1;
    int minimum = 100;

    for (int i = 0; i < 4; i++) {
        if (assignment[i] == -1) {
            int count = countAvailable(i, assignment, currentDomains);

            if (count < minimum) {
                minimum = count;
                best = i;
            }
        }
    }

    return best;
}

void showDomains(vector<int>& assignment,
                 vector<vector<int>>& currentDomains) {
    cout << "Remaining domains:\n";

    for (int i = 0; i < 4; i++) {
        if (assignment[i] != -1) {
            cout << courses[i] << " = {" << assignment[i] << "}\n";
        } else {
            cout << courses[i] << " = {";

            bool first = true;

            for (int slot : currentDomains[i]) {
                if (safe(i, slot, assignment)) {
                    if (!first) cout << ", ";
                    cout << slot;
                    first = false;
                }
            }

            cout << "}\n";
        }
    }

    cout << "\n";
}

bool solveMRVForwardChecking(vector<int>& assignment,
                             vector<vector<int>> currentDomains,
                             int assignedCount) {

    if (assignedCount == 4)
        return true;

    int course = chooseMRV(assignment, currentDomains);

    cout << "MRV selected: " << courses[course] << "\n";

    for (int slot : currentDomains[course]) {
        if (!safe(course, slot, assignment))
            continue;

        cout << "Assign " << courses[course]
             << " = Slot " << slot << "\n";

        assignment[course] = slot;

        vector<vector<int>> newDomains = currentDomains;
        bool valid = true;

        // Forward Checking:
        // remove this slot from conflicting unassigned courses
        for (int i = 0; i < 4; i++) {
            if (assignment[i] == -1 && conflict(course, i)) {

                vector<int> temp;

                for (int value : newDomains[i]) {
                    if (value != slot)
                        temp.push_back(value);
                }

                newDomains[i] = temp;

                if (newDomains[i].empty()) {
                    valid = false;
                    break;
                }
            }
        }

        showDomains(assignment, newDomains);

        if (valid &&
            solveMRVForwardChecking(assignment,
                                    newDomains,
                                    assignedCount + 1)) {
            return true;
        }

        cout << "Backtrack from " << courses[course] << "\n\n";
        assignment[course] = -1;
    }

    return false;
}

void printTimetable(vector<int>& assignment) {
    cout << "\nFinal timetable:\n";

    for (int i = 0; i < 4; i++) {
        cout << courses[i]
             << " -> Slot "
             << assignment[i] << "\n";
    }
}

int main() {
    cout << "===== SIMPLE BACKTRACKING =====\n";

    vector<int> assignment1(4, -1);

    if (simpleBacktracking(0, assignment1))
        printTimetable(assignment1);
    else
        cout << "No solution found.\n";

    cout << "\n===== MRV + FORWARD CHECKING =====\n";

    vector<int> assignment2(4, -1);

    cout << "Initial domains:\n";
    showDomains(assignment2, domains);

    if (solveMRVForwardChecking(assignment2, domains, 0))
        printTimetable(assignment2);
    else
        cout << "No solution found.\n";

    return 0;
}
