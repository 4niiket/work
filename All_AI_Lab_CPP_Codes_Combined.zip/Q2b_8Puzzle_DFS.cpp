#include <iostream>
#include <vector>
#include <string>
#include <queue>
#include <stack>
#include <unordered_set>
#include <unordered_map>
#include <algorithm>
using namespace std;

string goal = "123456780";

void printBoard(string s) {
    for (int i = 0; i < 9; i++) {
        if (s[i] == '0') cout << "# ";
        else cout << s[i] << " ";

        if (i % 3 == 2) cout << "\n";
    }
    cout << "\n";
}

vector<string> getNextStates(string s) {
    vector<string> next;

    int pos = s.find('0');
    int row = pos / 3;
    int col = pos % 3;

    int dr[] = {-1, 1, 0, 0};
    int dc[] = {0, 0, -1, 1};

    for (int i = 0; i < 4; i++) {
        int nr = row + dr[i];
        int nc = col + dc[i];

        if (nr >= 0 && nr < 3 && nc >= 0 && nc < 3) {
            int newPos = nr * 3 + nc;

            string temp = s;
            swap(temp[pos], temp[newPos]);
            next.push_back(temp);
        }
    }

    return next;
}

void printPath(unordered_map<string,string> parent, string endState) {
    vector<string> path;

    string cur = endState;

    while (cur != "") {
        path.push_back(cur);
        cur = parent[cur];
    }

    reverse(path.begin(), path.end());

    cout << "Number of moves: " << path.size() - 1 << "\n\n";

    for (string state : path)
        printBoard(state);
}


int main() {
    string start = "123046758";

    stack<string> st;
    unordered_set<string> visited;
    unordered_map<string,string> parent;

    st.push(start);
    parent[start] = "";

    while (!st.empty()) {
        string current = st.top();
        st.pop();

        if (visited.count(current))
            continue;

        visited.insert(current);

        if (current == goal) {
            cout << "Goal found using DFS\n\n";
            printPath(parent, current);
            return 0;
        }

        vector<string> nextStates = getNextStates(current);

        for (string next : nextStates) {
            if (!visited.count(next)) {
                if (!parent.count(next))
                    parent[next] = current;

                st.push(next);
            }
        }
    }

    cout << "No solution found\n";
    return 0;
}
