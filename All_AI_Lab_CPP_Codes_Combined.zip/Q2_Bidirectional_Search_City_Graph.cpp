#include <iostream>
#include <map>
#include <vector>
#include <queue>
#include <set>
#include <algorithm>
using namespace std;

int main() {
    map<char, vector<char>> graph;

    graph['A'] = {'B', 'C'};
    graph['B'] = {'A', 'D', 'E'};
    graph['C'] = {'A', 'F'};
    graph['D'] = {'B'};
    graph['E'] = {'B', 'G'};
    graph['F'] = {'C', 'G'};
    graph['G'] = {'E', 'F', 'H'};
    graph['H'] = {'G'};

    char source = 'A';
    char goal = 'H';

    queue<char> q1, q2;
    set<char> visited1, visited2;
    map<char, char> parent1, parent2;

    q1.push(source);
    q2.push(goal);

    visited1.insert(source);
    visited2.insert(goal);

    parent1[source] = '\0';
    parent2[goal] = '\0';

    char meeting = '\0';

    while (!q1.empty() && !q2.empty()) {

        int size1 = q1.size();

        while (size1--) {
            char u = q1.front();
            q1.pop();

            for (char v : graph[u]) {
                if (!visited1.count(v)) {
                    visited1.insert(v);
                    parent1[v] = u;
                    q1.push(v);

                    if (visited2.count(v)) {
                        meeting = v;
                        break;
                    }
                }
            }

            if (meeting != '\0')
                break;
        }

        if (meeting != '\0')
            break;

        int size2 = q2.size();

        while (size2--) {
            char u = q2.front();
            q2.pop();

            for (char v : graph[u]) {
                if (!visited2.count(v)) {
                    visited2.insert(v);
                    parent2[v] = u;
                    q2.push(v);

                    if (visited1.count(v)) {
                        meeting = v;
                        break;
                    }
                }
            }

            if (meeting != '\0')
                break;
        }

        if (meeting != '\0')
            break;
    }

    if (meeting == '\0') {
        cout << "No path found\n";
        return 0;
    }

    vector<char> leftPath;
    char cur = meeting;

    while (cur != '\0') {
        leftPath.push_back(cur);
        cur = parent1[cur];
    }

    reverse(leftPath.begin(), leftPath.end());

    vector<char> rightPath;
    cur = parent2[meeting];

    while (cur != '\0') {
        rightPath.push_back(cur);
        cur = parent2[cur];
    }

    cout << "Path: ";

    for (char x : leftPath)
        cout << x << " -> ";

    for (int i = 0; i < rightPath.size(); i++) {
        cout << rightPath[i];
        if (i != rightPath.size() - 1)
            cout << " -> ";
    }

    cout << "\nMeeting point: " << meeting << endl;

    cout << "Visited from source: ";
    for (char x : visited1)
        cout << x << " ";

    cout << "\nVisited from goal: ";
    for (char x : visited2)
        cout << x << " ";

    cout << endl;

    return 0;
}
