#include <iostream>
#include <vector>
#include <string>
using namespace std;

vector<char> regions = {'A', 'B', 'C', 'D', 'E'};
vector<string> colors = {"Red", "Green", "Blue"};

int adj[5][5] = {
    {0,1,1,0,0}, // A: B,C
    {1,0,1,1,1}, // B: A,C,D,E
    {1,1,0,0,1}, // C: A,B,E
    {0,1,0,0,1}, // D: B,E
    {0,1,1,1,0}  // E: B,C,D
};

bool safe(int node, int color, vector<int>& assignment) {
    for (int i = 0; i < 5; i++) {
        if (adj[node][i] && assignment[i] == color)
            return false;
    }
    return true;
}

bool backtracking(int node, vector<int>& assignment, int& attempts) {
    if (node == 5)
        return true;

    for (int color = 0; color < 3; color++) {
        attempts++;

        if (safe(node, color, assignment)) {
            assignment[node] = color;

            cout << "Assign " << regions[node]
                 << " = " << colors[color] << "\n";

            if (backtracking(node + 1, assignment, attempts))
                return true;

            cout << "Backtrack from " << regions[node] << "\n";
            assignment[node] = -1;
        }
    }

    return false;
}

int remainingValues(int node, vector<int>& assignment) {
    int count = 0;

    for (int color = 0; color < 3; color++) {
        if (safe(node, color, assignment))
            count++;
    }

    return count;
}

int chooseMRV(vector<int>& assignment) {
    int bestNode = -1;
    int minValues = 100;

    for (int i = 0; i < 5; i++) {
        if (assignment[i] == -1) {
            int count = remainingValues(i, assignment);

            if (count < minValues) {
                minValues = count;
                bestNode = i;
            }
        }
    }

    return bestNode;
}

bool backtrackingMRV(vector<int>& assignment, int assignedCount, int& attempts) {
    if (assignedCount == 5)
        return true;

    int node = chooseMRV(assignment);

    cout << "MRV selected: " << regions[node] << "\n";

    for (int color = 0; color < 3; color++) {
        attempts++;

        if (safe(node, color, assignment)) {
            assignment[node] = color;

            cout << "Assign " << regions[node]
                 << " = " << colors[color] << "\n";

            if (backtrackingMRV(assignment, assignedCount + 1, attempts))
                return true;

            cout << "Backtrack from " << regions[node] << "\n";
            assignment[node] = -1;
        }
    }

    return false;
}

void printSolution(vector<int>& assignment) {
    cout << "\nFinal color assignment:\n";

    for (int i = 0; i < 5; i++) {
        cout << regions[i] << " = "
             << colors[assignment[i]] << "\n";
    }
}

int main() {
    cout << "===== NORMAL BACKTRACKING =====\n";

    vector<int> assignment1(5, -1);
    int attempts1 = 0;

    if (backtracking(0, assignment1, attempts1)) {
        printSolution(assignment1);
        cout << "Assignments tried: " << attempts1 << "\n";
    } else {
        cout << "No solution found.\n";
    }

    cout << "\n===== BACKTRACKING WITH MRV =====\n";

    vector<int> assignment2(5, -1);
    int attempts2 = 0;

    if (backtrackingMRV(assignment2, 0, attempts2)) {
        printSolution(assignment2);
        cout << "Assignments tried: " << attempts2 << "\n";
    } else {
        cout << "No solution found.\n";
    }

    cout << "\nComparison:\n";
    cout << "Normal Backtracking attempts = " << attempts1 << "\n";
    cout << "MRV Backtracking attempts = " << attempts2 << "\n";

    return 0;
}
