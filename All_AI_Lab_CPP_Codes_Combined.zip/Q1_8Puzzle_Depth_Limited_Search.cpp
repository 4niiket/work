#include <iostream>
#include <vector>
#include <string>
#include <unordered_set>
using namespace std;

string goal = "123456780";
int nodesExpanded = 0;

vector<pair<string, string>> getNextStates(string state) {
    vector<pair<string, string>> nextStates;

    int pos = state.find('0');
    int row = pos / 3;
    int col = pos % 3;

    int dr[] = {-1, 1, 0, 0};
    int dc[] = {0, 0, -1, 1};
    string moveName[] = {"Up", "Down", "Left", "Right"};

    for (int i = 0; i < 4; i++) {
        int newRow = row + dr[i];
        int newCol = col + dc[i];

        if (newRow >= 0 && newRow < 3 && newCol >= 0 && newCol < 3) {
            int newPos = newRow * 3 + newCol;

            string newState = state;
            swap(newState[pos], newState[newPos]);

            nextStates.push_back({newState, moveName[i]});
        }
    }

    return nextStates;
}

bool DLS(string state, int depth, int limit,
         unordered_set<string>& visited,
         vector<string>& moves) {

    nodesExpanded++;

    if (state == goal)
        return true;

    if (depth == limit)
        return false;

    visited.insert(state);

    for (auto next : getNextStates(state)) {
        string nextState = next.first;
        string move = next.second;

        if (!visited.count(nextState)) {
            moves.push_back(move);

            if (DLS(nextState, depth + 1, limit, visited, moves))
                return true;

            moves.pop_back();
        }
    }

    visited.erase(state);
    return false;
}

int main() {
    string start = "123406758";
    int depthLimit = 10;

    unordered_set<string> visited;
    vector<string> moves;

    bool found = DLS(start, 0, depthLimit, visited, moves);

    if (found) {
        cout << "Goal found within depth limit.\n";

        cout << "Moves: ";
        for (int i = 0; i < moves.size(); i++) {
            cout << moves[i];
            if (i != moves.size() - 1)
                cout << " -> ";
        }

        cout << "\nDepth: " << moves.size();
    } else {
        cout << "Goal not found within depth limit.";
    }

    cout << "\nNodes expanded: " << nodesExpanded << endl;

    return 0;
}
