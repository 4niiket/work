#include <iostream>
#include <vector>
#include <string>
#include <queue>
#include <stack>
#include <unordered_set>
#include <unordered_map>
#include <algorithm>
using namespace std;

string goal = "123456780";

void printBoard(string s) {
    for (int i = 0; i < 9; i++) {
        if (s[i] == '0') cout << "# ";
        else cout << s[i] << " ";

        if (i % 3 == 2) cout << "\n";
    }
    cout << "\n";
}

vector<string> getNextStates(string s) {
    vector<string> next;

    int pos = s.find('0');
    int row = pos / 3;
    int col = pos % 3;

    int dr[] = {-1, 1, 0, 0};
    int dc[] = {0, 0, -1, 1};

    for (int i = 0; i < 4; i++) {
        int nr = row + dr[i];
        int nc = col + dc[i];

        if (nr >= 0 && nr < 3 && nc >= 0 && nc < 3) {
            int newPos = nr * 3 + nc;

            string temp = s;
            swap(temp[pos], temp[newPos]);
            next.push_back(temp);
        }
    }

    return next;
}

void printPath(unordered_map<string,string> parent, string endState) {
    vector<string> path;

    string cur = endState;

    while (cur != "") {
        path.push_back(cur);
        cur = parent[cur];
    }

    reverse(path.begin(), path.end());

    cout << "Number of moves: " << path.size() - 1 << "\n\n";

    for (string state : path)
        printBoard(state);
}


int heuristic(string s) {
    int mismatch = 0;

    for (int i = 0; i < 9; i++) {
        if (s[i] != '0' && s[i] != goal[i])
            mismatch++;
    }

    return mismatch;
}

int main() {
    string start = "123046758";

    priority_queue<
        pair<int,string>,
        vector<pair<int,string>>,
        greater<pair<int,string>>
    > pq;

    unordered_map<string,int> g;
    unordered_map<string,string> parent;

    g[start] = 0;
    parent[start] = "";

    pq.push({heuristic(start), start});

    while (!pq.empty()) {
        string current = pq.top().second;
        int fValue = pq.top().first;
        pq.pop();

        if (current == goal) {
            cout << "Goal found using A*\n\n";
            printPath(parent, current);
            return 0;
        }

        for (string next : getNextStates(current)) {
            int newG = g[current] + 1;

            if (!g.count(next) || newG < g[next]) {
                g[next] = newG;
                parent[next] = current;

                int f = newG + heuristic(next);
                pq.push({f, next});
            }
        }
    }

    cout << "No solution found\n";
    return 0;
}
