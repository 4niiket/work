#include <iostream>
#include <vector>
#include <queue>
#include <map>
#include <climits>
#include <algorithm>
using namespace std;

int main() {
    map<char, vector<pair<char,int>>> graph;

    graph['a'] = {{'b',5}, {'c',2}, {'d',3}};
    graph['b'] = {{'a',5}, {'c',2}, {'f',3}};
    graph['c'] = {{'a',2}, {'b',2}, {'d',1}, {'e',2}, {'f',6}};
    graph['d'] = {{'a',3}, {'c',1}, {'e',4}};
    graph['e'] = {{'d',4}, {'c',2}, {'f',4}};
    graph['f'] = {{'b',3}, {'c',6}, {'e',4}};

    map<char,int> dist;
    map<char,char> parent;

    for (char x = 'a'; x <= 'f'; x++)
        dist[x] = INT_MAX;

    priority_queue<pair<int,char>,
                   vector<pair<int,char>>,
                   greater<pair<int,char>>> pq;

    dist['a'] = 0;
    pq.push({0, 'a'});

    while (!pq.empty()) {
        int d = pq.top().first;
        char u = pq.top().second;
        pq.pop();

        if (d != dist[u]) continue;

        for (auto edge : graph[u]) {
            char v = edge.first;
            int w = edge.second;

            if (dist[u] + w < dist[v]) {
                dist[v] = dist[u] + w;
                parent[v] = u;
                pq.push({dist[v], v});
            }
        }
    }

    vector<char> path;
    char cur = 'f';

    while (cur != 'a') {
        path.push_back(cur);
        cur = parent[cur];
    }
    path.push_back('a');

    reverse(path.begin(), path.end());

    cout << "Shortest path: ";
    for (char x : path)
        cout << x << " ";

    cout << "\nCost: " << dist['f'] << endl;

    return 0;
}
